import 'package:flutter/material.dart';
import 'package:flutter_application_4/models/models.dart';

class ProductFormProvider extends ChangeNotifier {
  Product product;

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  ProductFormProvider(this.product);

  bool isValidForm() {
    return formKey.currentState?.validate() ?? false;
  }

  updateAvailability(bool value) {
    product.available = value;
    notifyListeners();
  }
}
