import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_application_4/models/models.dart';

class ProductsService with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<Product> _products = [];
  Product? selectedProduct;
  bool isLoading = true;
  bool isSaving = false;

  List<Product> get products => _products;

  ProductsService() {
    fetchProducts();
  }

  Future<List<Product>> fetchProducts() async {
    isLoading = true;
    notifyListeners();

    final snapshot = await _firestore.collection('products').get();
    _products = snapshot.docs.map((doc) => Product.fromDocument(doc)).toList();

    isLoading = false;
    notifyListeners();
    return _products;
  }

  Future<bool> saveOrCreateProduct(Product product) async {
    isSaving = true;
    notifyListeners();

    if (product.id == null) {
      // Es necesario crear
      return await createProduct(product);
    } else {
      // Es necesario actualizar
      return await updateProduct(product);
    }
  }

  Future<bool> updateProduct(Product product) async {
    final url = Uri.parse("${Environment.apiUrl}/products/${product.id}");
    final resp = await http.put(
      url,
      body: product.toJson(),
      headers: {"Content-Type": "application/json"},
    );

    if (resp.statusCode == 200) {
      final index = products.indexWhere((element) => element.id == product.id);
      products[index] = product;
      return true;
    }

    return false;
  }

  Future<bool> createProduct(Product product) async {
    final url = Uri.parse("${Environment.apiUrl}/products");
    final resp = await http.post(
      url,
      body: product.toJson(),
      headers: {"Content-Type": "application/json"},
    );

    if (resp.statusCode == 200) {
      final newProduct = Product.fromJson(resp.body);
      products.add(newProduct);
      return true;
    }

    return false;
  }

  void updateSelectedProductImage(String path) {
    selectedProduct?.picture = path;
    notifyListeners();
  }
}
