import 'package:flutter/material.dart';
import 'package:firebase_functions/firebase_functions.dart';
import 'package:flutter_application_4/models/models.dart';

class CartService with ChangeNotifier {
  List<Product> _cart = [];

  List<Product> get cart => _cart;

  void addToCart(Product product) {
    _cart.add(product);
    notifyListeners();
  }

  void removeFromCart(Product product) {
    _cart.remove(product);
    notifyListeners();
  }

  Future<bool> completePurchase(String email) async {
    try {
      final HttpsCallable callable =
          FirebaseFunctions.instance.httpsCallable('completePurchase');
      final response = await callable.call({
        'products': _cart
            .map((product) =>
                {'id': product.id, 'name': product.name, 'quantity': 1})
            .toList(),
        'email': email
      });
      final success = response.data['success'];
      if (success) {
        _cart.clear();
        notifyListeners();
      }
      return success;
    } catch (e) {
      return false;
    }
  }
}
