import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_application_4/global/environment.dart';
import 'package:flutter_application_4/models/models.dart';

class AuthService extends ChangeNotifier {
  User? user;
  bool _authenticating = false;

  final _storage = FlutterSecureStorage();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool get authenticating => _authenticating;
  set authenticating(bool value) {
    _authenticating = value;
    notifyListeners();
  }

  // Getters del token de forma estatica
  static Future<String?> getToken() async {
    final _storage = FlutterSecureStorage();
    return await _storage.read(key: "token");
  }

  static Future<void> deleteToken() async {
    final _storage = FlutterSecureStorage();
    await _storage.delete(key: "token");
  }

  Future<bool> login(String email, String password) async {
    authenticating = true;
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      authenticating = false;
      return true;
    } catch (e) {
      authenticating = false;
      return false;
    }
  }

  Future<bool> register(String email, String password) async {
    authenticating = true;
    try {
      await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      authenticating = false;
      return true;
    } catch (e) {
      authenticating = false;
      return false;
    }
  }

  Future<bool> isLoggedIn() async {
    return _auth.currentUser != null;
  }

  Future<void> logout() async {
    await _auth.signOut();
    await _storage.delete(key: "token");
  }
}
