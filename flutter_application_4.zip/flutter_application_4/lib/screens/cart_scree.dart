import 'package:flutter/material.dart';
import 'package:flutter_application_4/services/auth_service.dart';
import 'package:flutter_application_4/models/models.dart';
import 'package:flutter_application_4/services/services.dart';
import 'package:provider/provider.dart';

import '../services/cart_service.dart';

class CartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cartService = Provider.of<CartService>(context);
    final authService = Provider.of<AuthService>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text("Cart"),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: cartService.cart.length,
              itemBuilder: (context, index) {
                final product = cartService.cart[index];
                return ListTile(
                  title: Text(product.name),
                  subtitle: Text("${product.price}"),
                  trailing: IconButton(
                    icon: Icon(Icons.remove_shopping_cart),
                    onPressed: () => cartService.removeFromCart(product),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () async {
                final success = await cartService
                    .completePurchase(authService.user?.email ?? "");
                if (success) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("Purchase completed successfully!"),
                  ));
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("Out of stock for some products."),
                  ));
                }
              },
              child: Text("Complete Purchase"),
            ),
          ),
        ],
      ),
    );
  }
}
