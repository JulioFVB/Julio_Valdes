import 'package:flutter/material.dart';
import 'package:flutter_application_4/models/models.dart';
import 'package:flutter_application_4/services/services.dart';
import 'package:flutter_application_4/widgets/widgets.dart';
import 'package:provider/provider.dart';

class ListProductScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final productsService = Provider.of<ProductsService>(context);
    final products = productsService.products;

    if (productsService.isLoading) return LoadingScreen();

    return Scaffold(
      appBar: AppBar(
        title: Text("Products"),
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) => GestureDetector(
          onTap: () {
            productsService.selectedProduct = products[index].copy();
            Navigator.pushNamed(context, "product");
          },
          child: ProductCard(product: products[index]),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          productsService.selectedProduct = new Product(
            name: "",
            price: 0,
            available: true,
          );
          Navigator.pushNamed(context, "product");
        },
      ),
    );
  }
}
