import 'package:cloud_firestore/cloud_firestore.dart';

class Product {
  String? id;
  String name;
  String category;
  String? flavor;
  double price;
  int stock;
  bool available;
  String? picture;
  String? user;

  Product({
    this.id,
    required this.name,
    required this.category,
    this.flavor,
    required this.price,
    required this.stock,
    required this.available,
    this.picture,
    this.user,
  });

  factory Product.fromMap(Map<String, dynamic> map) => Product(
        id: map["id"],
        name: map["name"],
        category: map["category"],
        flavor: map["flavor"],
        price: map["price"],
        stock: map["stock"],
        available: map["available"],
        picture: map["picture"],
        user: map["user"],
      );

  factory Product.fromDocument(DocumentSnapshot doc) => Product(
        id: doc.id,
        name: doc['name'],
        category: doc['category'],
        flavor: doc['flavor'],
        price: doc['price'],
        stock: doc['stock'],
        available: doc['available'],
        picture: doc['picture'],
        user: doc['user'],
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "name": name,
        "category": category,
        "flavor": flavor,
        "price": price,
        "stock": stock,
        "available": available,
        "picture": picture,
        "user": user,
      };

  Product copy() => Product(
        id: id,
        name: name,
        category: category,
        flavor: flavor,
        price: price,
        stock: stock,
        available: available,
        picture: picture,
        user: user,
      );
}
